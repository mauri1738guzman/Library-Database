<!DOCTYPE html>
<html>
<head>
    <title>Edit Item Success</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdn.simplecss.org/simple.min.css">
</head>
<body>
    <?php include 'empnav.php'; ?>
    <h1>Edit Item Success</h1>
    <p>The item has been successfully updated.</p>
    <a href="report_item.php">Back to Item Report</a>
</body>
</html>

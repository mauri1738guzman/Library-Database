<!DOCTYPE html>
<html>

<head>
    <title>Update Employee Success</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdn.simplecss.org/simple.min.css">
</head>

<body>
    <h1>Employee Updated Successfully!</h1>

    <a href="report_employee.php">Return to Employee Report</a>
</body>

</html>

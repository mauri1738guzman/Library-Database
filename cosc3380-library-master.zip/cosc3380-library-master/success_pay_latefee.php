<!DOCTYPE html>
<html>

<head>
    <title>Pay Late Fee Success</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdn.simplecss.org/simple.min.css">
</head>

<body>
    <?php include 'membernav.php'; ?>
    <h1>Pay Late Fee Success</h1>
    <p>Your late fee has been paid successfully.</p>
</body>

</html>

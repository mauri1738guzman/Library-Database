
<div style="display: inline-block;">
    <a href="main.php"><button>Home</button></a>
    <a href="add_to_cart.php"><button>Cart</button></a>
    <a href="myorders.php"><button>My Order</button></a>
    <a href="myreservation.php"><button>My Reservation</button></a>
    <a href="update_member.php"><button>Change Information</button></a>
    <a href="latefee.php"><button>Late Fee</button></a>
    <a href="messages.php"><button>Messages</button></a>
    <a href="logout.php"><button>Sign Out</button></a>
</div>
